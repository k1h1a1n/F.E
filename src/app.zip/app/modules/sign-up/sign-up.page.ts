import { Component } from '@angular/core';
import { MenuController, LoadingController } from '@ionic/angular';
import { NavigationService } from '@durity/services';
import { Validators, FormBuilder, FormGroup, AbstractControl } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { GetPhonecodesService } from 'src/app/shared/services/get-phonecodes.service';
import { UploadDocumentsService } from 'src/app/shared/services/upload-documents.service';



@Component({
    selector: 'app-sign-up',
    templateUrl: './sign-up.page.html',
    styleUrls: ['./sign-up.page.scss'],
})

export class SignUpPage {

    appName = 'Durity';
    countryCodes: { Name: string; ISO: string; Code: string; }[];
    selectedCountry: any;
    signUpForm: FormGroup;
    passwordShown = false;
    passwordType = 'password';
    passwordIcon = 'eye-off';

    constructor (
        private navService: NavigationService,
        private authService: AuthService,
        private codeService: GetPhonecodesService,
        private formBuilder: FormBuilder,
        private UploadDocumentsService: UploadDocumentsService,
        private loaderCtrl: LoadingController,
        public menuCtrl: MenuController

    ) {
        this.countryCodes = this.codeService.getCountryCodes();
        this.selectedCountry = this.countryCodes[94];
        this.menuCtrl.swipeGesture(false);
        this.signUpForm = this.formBuilder.group({
            email: ['', [
                Validators.required,
                Validators.pattern(String.raw`^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$`)
            ]],
            password: ['', [
                Validators.required,
                Validators.minLength(6)
            ]],
            name: ['', [
                Validators.required,
                Validators.pattern(String.raw`^[ +A-Za-z'-]+$`)
            ]],
            telephoneNumber: ['',  [
                     Validators.required, Validators.maxLength(15),
                     Validators.pattern(String.raw`^[0-9]*$`)
                    //  Validators.pattern(String.raw`^(?:(?:\+|0{0,2})01(\s*[\ -]\s*)?|[0]?)?[789]\d{9}|(\d[ -]?){10}\d$`)
                 ]]
        });
    }


ionViewWillEnter () {
        this.menuCtrl.swipeGesture(false);
        this.menuCtrl.enable(false);
    }
   onChange (event) {
       this.selectedCountry = event;

   }

async register () {
    if ( this.signUpForm.valid) {
        Object.keys(this.signUpForm.controls).forEach((key) =>
        this.signUpForm.get(key).setValue(this.signUpForm.get(key).value.trim()));
        const loader = await this.loaderCtrl.create({
            message: 'Please wait...'
        });
        (await loader).present();

        const credentials = {
            name : this.signUpForm.value.name,
            email: this.signUpForm.value.email,
            telephoneNumber: this.selectedCountry.Code + this.signUpForm.value.telephoneNumber ,
            password: this.signUpForm.value.password

                  };
        this.authService.attemptAuth('register', credentials).then(res => {
               this.loaderCtrl.dismiss();
               this.authService.presentToast('Registration Successfull!');
               this.UploadDocumentsService.createWillFile(this.signUpForm.value.name,this.signUpForm.value.email);
               this.navService.navigateRoot('/add-contacts');
           }).catch(err => {
               this.loaderCtrl.dismiss();
               this.authService.presentToast('Error in Registering, Please try after sometime');
           });
    }

    }


showPassword () {
        this.passwordType = this.passwordType === 'text' ? 'password' : 'text';
        this.passwordIcon = this.passwordIcon === 'eye-off' ? 'eye' : 'eye-off';

    }

signUpWithGoogle () {
    }

goto (page) {
        switch (page) {
            case 'signIn':
                this.navService.navigateRoot('login');
                break;

            default:
                break;
        }
    }


}
