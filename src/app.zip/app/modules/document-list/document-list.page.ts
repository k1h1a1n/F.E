import { Component, OnInit } from '@angular/core';
import { NavigationService, UserService } from '@durity/services';
import { Router } from '@angular/router';
import { GlobalVariablesService } from 'src/app/services/global-variables.service';
import { ApiService } from 'src/app/services/api.service';
import { ModalController} from '@ionic/angular';
import { DeletePopoverComponent } from 'src/app/shared/components/delete-popover/delete-popover.component';
import { DownloadDocumentService } from 'src/app/shared/services/download-document.service';

@Component({
    selector: 'app-document-list',
    templateUrl: './document-list.page.html',
    styleUrls: ['./document-list.page.scss'],
})
export class DocumentListPage implements OnInit {
    attachments = [];
    signInType: string;


    constructor (
        public navService: NavigationService,
        private router: Router,
        public globalVariablesProvider: GlobalVariablesService,
        private apiService: ApiService,
        private downloadDocumentService: DownloadDocumentService,
        private modalCtrl: ModalController
    ) {

         this.getAttachments();
    }
    ionViewWillEnter () {
        this.getAttachments();
        this.signInType = this.globalVariablesProvider.signInType;

    }
    ngOnInit () {
        this.getAttachments();
    }

    getAttachments () {
        this.apiService.get({ name: 'myFiles' }).subscribe(attachments => {
            this.attachments = attachments;
            console.log(this.attachments);
        }, error => {
        });

    }


    download (fileName, fileId, isEncrypted) {
        this.downloadDocumentService.downloadFile(fileName, fileId, isEncrypted);
    }
    goto (pageName, data?) {
        this.navService.goto(pageName, data);
    }

    addDocument () {
        this.navService.navigateForword(['select-doc']);
    }

    viewDocument (index) {
        this.router.navigate(['/view-document', index]);
    }

    next () {
        this.navService.navigateRoot('/everything-set');
    }

    async deleteAttachment (fileId) {
        const modal = await this.modalCtrl.create({
            component: DeletePopoverComponent,
            cssClass: 'simple-delete-modal',
            componentProps: { deleteType: 'deleteAttachment', fileId }
        });
        await modal.present();
        const { } = await modal.onWillDismiss();
        this.getAttachments ();

    }
}
