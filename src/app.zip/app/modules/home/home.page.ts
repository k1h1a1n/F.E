import { Component } from '@angular/core';
import { NavigationService, UserService } from '@durity/services';
import { MenuController, NavController, ModalController } from '@ionic/angular';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { environment } from 'src/environments/environment';
import { GlobalVariablesService } from 'src/app/services/global-variables.service';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { ContactServiceService } from 'src/app/shared/services/contact-service.service';
import { AttachmentsService } from 'src/app/shared/services/attachments.service';
import { ApiService } from 'src/app/services/api.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { UploadDocumentsService } from 'src/app/shared/services/upload-documents.service';

declare var window: any;
declare var device: any;



@Component({
    selector: 'app-home',
    templateUrl: 'home.page.html',
    styleUrls: ['home.page.scss'],
})
export class HomePage {
    apiUrl: string = environment.apiUrl;
    attachments = [];
    attachmentsPreview = [];
    family = 'Family';
    friends = 'Friends';
    others = 'Other';
    userName: string;
    useremail: string;
    userData: any;
    userDetails: any;
    isUserEncryptionEnabled: any;
    size: any;
    userId: string;
    token: string;
    header: HttpHeaders;
    hashValue: string;
    biometricKey: any;

    constructor (
        private userService: UserService,
        private navService: NavigationService,
        private router: Router,
        private auth: AuthService,
        public menuCtrl: MenuController,
        public modalCtrl: ModalController,
        private attachmentService: AttachmentsService,
        private navCtrl: NavController,
        private apiService: ApiService,
        private UploadDocumentsService: UploadDocumentsService,
        public globalVariablesProvider: GlobalVariablesService,
        private contactService: ContactServiceService,
        private http: HttpClient
    ) {
        this.auth.currentUser.subscribe((user) => {
            this.userId = user._id;
            this.token = user.token;
            this.header = new HttpHeaders({
             'content-type': 'application/json',
             Authorization: this.token,
         });
         });

        this.http.get(`${this.apiUrl}/user/getuserinfo?user_id=${this.userId}`, {headers: this.header}).subscribe((res) => {
            this.auth.setAuth(res);
        });

        this.attachmentService.getAttachments ();
        this.auth.configuration.subscribe((info) => {
            this.isUserEncryptionEnabled = info.configuration.isUserEncryptionEnabled;
        });
        // });
        this.globalVariablesProvider.isUserEncryptionEnabled = this.isUserEncryptionEnabled;
        this.globalVariablesProvider.signInType = 'login';
        this.userData = this.auth.currentUser.subscribe(user => (this.userName = user.profile.name, this.userDetails = user));
        this.contactService.getContacts();
        this.globalVariablesProvider.addMoreContacts = false;
        this.generateBiometricPublicKey();
    }

    ionViewWillEnter () {
        this.getAttachments();
        this.menuCtrl.enable(true);
    }

    getAttachments () {
        this.apiService.get({name: 'myFiles'}).subscribe(attachments => {
            this.attachments = attachments;
            if (this.attachments.length > 0 && this.attachments.length > 5) {
                for (let i = 0; i < 5; i++) {
                    this.attachmentsPreview[i] = this.attachments[i];
                }
            } else {
                this.attachmentsPreview = this.attachments.slice();
            }
        }, error => {
        });

    }

    viewDocument (index) {
        this.router.navigate(['/view-document', index]);
    }

    goto (pageName, data?) {
        this.navService.goto(pageName, data);
    }

    addDocument () {
        this.navCtrl.navigateForward('/select-doc');
    }

    viewAllDocuments () {
        this.navService.navigateForword('/document-list');
    }

    async familyContactsTab () {
        this.navService.navigateRoot('contact-list');
        const relation = this.family;
        localStorage.setItem('relation', relation);
    }

    async friendsContactsTab () {
        this.navService.navigateRoot('contact-list');
        const relation = this.friends;
        localStorage.setItem('relation', relation);
    }

    async othersContactsTab () {
        this.navService.navigateRoot('contact-list');
        const relation = this.others;
        localStorage.setItem('relation', relation);
    }

    generateBiometricPublicKey() {
        window.cordova.plugins.CustomBiometricPlugin.generatePublicKey(1024, "mdurity",
          (res) => {
              console.log(res);
              this.biometricKey = res;
          },
          (err) =>{return err} 
        );
      }

  async addDeviceToBiometric(){
        
       
        var userDeviceDetails = {
            operatingSystem: device.platform,
            UUID: device.uuid,
            keyStoreId: 'mdurity',
            deviceType: 'mobile',
            publicKeyId: this.biometricKey,
            userId: this.userDetails._id,
            encRandKey: '',
            encRandIv: ''
        }
        
        this.UploadDocumentsService.addDevicForBiometric(userDeviceDetails);
    }

}
