// import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { LoginHomePage } from './login-home.page';

// describe('LoginHomePage', () => {
//   let component: LoginHomePage;
//   let fixture: ComponentFixture<LoginHomePage>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ LoginHomePage ],
//       schemas: [CUSTOM_ELEMENTS_SCHEMA],
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(LoginHomePage);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
