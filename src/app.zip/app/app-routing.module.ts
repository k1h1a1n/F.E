import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { SharedModule } from './shared/shared.module';
import { SelectDocumentTypeComponent, ViewDocumentComponent, SetPasswordComponent, DisclaimerComponent, ConfirmPasswordComponent, ShareDetailsComponent, UserEncryptionOptionsComponent, UploadDocumentComponent, CreateContactComponent } from '@durity/components';
import { EncryptDetailsComponent } from './shared/components/signup-wizard/encrypt-details/encrypt-details.component';
import { AddContactsComponent } from './shared/components/signup-wizard/add-contacts/add-contacts.component';
import { SecurityComponent } from './shared/components/signup-wizard/security/security.component';
import { EverythingSetComponent } from './shared/components/signup-wizard/everything-set/everything-set.component';
import { StorePasswordComponent } from './shared/components/store-password/store-password.component';
import { RecommendationsComponent } from './shared/recommendations/recommendations.component';
import { EditContactComponent } from './shared/components/edit-contact/edit-contact.component';
import { ToastComponent } from './shared/components/toast/toast.component';
import { TextNoteComponent } from './shared/components/text-note/text-note.component';
import { TextNoteUploadComponent } from './shared/components/text-note-upload/text-note-upload.component';
import { FeedbackComponent } from './shared/components/feedback/feedback.component';
import { FeedbackSubmitComponent } from './shared/components/feedback-submit/feedback-submit.component';
import { FaqsComponent } from './shared/components/faqs/faqs.component';
import { ProfileScreenComponent } from './shared/components/profile-screen/profile-screen.component';
import { UploadProfilePicComponent } from './shared/components/upload-profile-pic/upload-profile-pic.component';
import { EnterFileDownloadOtpComponent } from './shared/components/enter-file-download-otp/enter-file-download-otp.component';
import { EnterOTPandDecryptFileComponent } from './shared/components/enter-otpand-decrypt-file/enter-otpand-decrypt-file.component';
import { ChangePasswordComponent } from './shared/components/change-password/change-password.component';
import { ContactUsComponent } from './shared/components/contact-us/contact-us.component';
import { SettingsComponent } from './shared/components/settings/settings.component';
const routes: Routes = [
    {
        path: '',
        redirectTo: 'login',
        pathMatch: 'full'
    },
    {
        path: 'home',
        loadChildren: './modules/home/home.module#HomePageModule'
    },
    {
        path: 'documents',
        loadChildren: './modules/home/home.module#HomePageModule'
    },
    {
        path: 'login',
        loadChildren: './modules/login/login.module#LoginPageModule'
    },
    {
        path: 'sign-up',
        loadChildren: './modules/sign-up/sign-up.module#SignUpPageModule'
    },
    { path: 'login-home', loadChildren: './modules/login-home/login-home.module#LoginHomePageModule' },
    { path: 'document-list', loadChildren: './modules/document-list/document-list.module#DocumentListPageModule' },
    { path: 'contact-list', loadChildren: './modules/contact-list/contact-list.module#ContactListPageModule' },
    { path: 'view-document/:index', component: ViewDocumentComponent},
    { path:'change-password', component:ChangePasswordComponent },
    { path:'settings', component:SettingsComponent},
    { path:'contact-us', component:ContactUsComponent},
    {path: 'recommendations', component: RecommendationsComponent},
    { path: 'select-doc', component: SelectDocumentTypeComponent },
    { path: 'encrypt-details', component: EncryptDetailsComponent},
    { path:'enter-file-download-otp', component:EnterFileDownloadOtpComponent},
    { path:'enter-otp-decrypt-file', component:EnterOTPandDecryptFileComponent},
    {path: 'add-contacts', component: AddContactsComponent},
    { path: 'security', component: SecurityComponent},
    { path: 'everything-set', component: EverythingSetComponent},
    { path: 'set-pass' , component: SetPasswordComponent},
    { path: 'disclaimer', component: DisclaimerComponent},
    { path: 'store-password' , component: StorePasswordComponent},
    {path: 'confirm-pass' , component: ConfirmPasswordComponent},
    {path: 'userencryption-opt' , component: UserEncryptionOptionsComponent},
    {path: 'share-details', component: ShareDetailsComponent},
    { path: 'text-note' , component: TextNoteComponent},
    {path: 'upload-document' , component: UploadDocumentComponent},
   { path: 'forgot-password', loadChildren: './modules/forgot-password/forgot-password.module#ForgotPasswordPageModule' },
   {path: 'create-contact', component: CreateContactComponent},
   {path: 'edit-contact', component: EditContactComponent},
   { path: 'toast' , component: ToastComponent},
   {path: 'upload-text-note', component: TextNoteUploadComponent},
   { path: 'feedback', component: FeedbackComponent},
   { path: 'feedback-submit', component: FeedbackSubmitComponent},
   { path: 'faqs', component: FaqsComponent},
   { path: 'profile-screen', component: ProfileScreenComponent},
   {path: 'upload-profilePic', component: UploadProfilePicComponent}

];

@NgModule({
    imports: [
        SharedModule,
        RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
    ],
    exports: [RouterModule]
})
export class AppRoutingModule { }
