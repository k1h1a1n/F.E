// import { TestBed } from '@angular/core/testing';

// import { GetPhonecodesService } from './get-phonecodes.service';

// describe('GetPhonecodesService', () => {
//   beforeEach(() => TestBed.configureTestingModule({}));

//   it('should be created', () => {
//     const service: GetPhonecodesService = TestBed.get(GetPhonecodesService);
//     expect(service).toBeTruthy();
//   });
// });
