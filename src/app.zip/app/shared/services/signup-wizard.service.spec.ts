// import { TestBed } from '@angular/core/testing';

// import { SignupWizardService } from './signup-wizard.service';

// describe('SignupWizardService', () => {
//   beforeEach(() => TestBed.configureTestingModule({}));

//   it('should be created', () => {
//     const service: SignupWizardService = TestBed.get(SignupWizardService);
//     expect(service).toBeTruthy();
//   });
// });
