// import { TestBed } from '@angular/core/testing';

// import { SelectDocumentService } from './select-document.service';

// describe('SelectDocumentService', () => {
//   beforeEach(() => TestBed.configureTestingModule({}));

//   it('should be created', () => {
//     const service: SelectDocumentService = TestBed.get(SelectDocumentService);
//     expect(service).toBeTruthy();
//   });
// });
