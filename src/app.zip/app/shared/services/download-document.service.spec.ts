// import { TestBed } from '@angular/core/testing';

// import { DownloadDocumentService } from './download-document.service';

// describe('DownloadDocumentService', () => {
//   beforeEach(() => TestBed.configureTestingModule({}));

//   it('should be created', () => {
//     const service: DownloadDocumentService = TestBed.get(DownloadDocumentService);
//     expect(service).toBeTruthy();
//   });
// });
