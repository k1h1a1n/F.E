import { Component, OnInit } from '@angular/core';
import { NavigationService } from '@durity/services';
import { NavController, ModalController, AlertController, LoadingController, ToastController, PopoverController } from '@ionic/angular';
import { ContactServiceService } from '../../services/contact-service.service';
import { ActivatedRoute } from '@angular/router';
import { environment } from 'src/environments/environment';
import { ConfirmPasswordComponent } from '../confirm-password/confirm-password.component';
import { GlobalVariablesService } from 'src/app/services/global-variables.service';
import { DeletePopoverComponent } from '../delete-popover/delete-popover.component';
import { UploadDocumentComponent } from '../upload-document/upload-document.component';
import { DownloadDocumentService } from '../../services/download-document.service';
import { AttachmentsService } from '../../services/attachments.service';
import { UploadDocumentsService } from '../../services/upload-documents.service';
import { AndroidPermissions } from '@ionic-native/android-permissions/ngx';
import { AuthService } from 'src/app/services/auth.service';
import { ApiService } from 'src/app/services/api.service';
import { EnterFileDownloadOtpComponent } from '../enter-file-download-otp/enter-file-download-otp.component';
import { EnterOTPandDecryptFileComponent } from '../enter-otpand-decrypt-file/enter-otpand-decrypt-file.component';



declare var window: any;

@Component({
  selector: 'app-view-document',
  templateUrl: './view-document.component.html',
  styleUrls: ['./view-document.component.scss'],
})
export class ViewDocumentComponent implements OnInit {
  url = environment.apiUrl;
  attachments = [];
  contacts = [];
  beneficiary1: any = [{}];
  beneficiary2: any = [{}];
  beneficiary3: any = [{}];
  contact: string;
  contactId: any = [];
  dataReturned: any;
  document: any;
  extension: string;
  isBiometricEnabled: any;
  fileExtension: string;
  fileName: any;
  fileId: string;
  isEncrypted: boolean;
  lockToshow:boolean = false;
  index: string;
  isUserEncrypted: any;
  biometricDecryptKey: any;
  name: any = [{}];
  tier1: Array<{}> = [];
  tier2: Array<{}> = [];
  tier3: Array<{}> = [];
  userId: string;
  hybridEncTag: string;
  userFileEncKeyhash:string;
  userFileEncIv:string;
  userFileEncTag:string;
  uploadedDate: string;
  all: string[];
  fileSize: string;
  alert: any;
  nofileSize = false;
  user;


  constructor (
               public alertCtrl: AlertController,
               private androidPermissions: AndroidPermissions,
               public navService: NavigationService,
               public navCtrl: NavController,
               public loadingCtrl: LoadingController,
               private attachmentService: AttachmentsService,
               private apiService: ApiService,
               public toastCtrl: ToastController,
              //  private EnterOTPandDecryptFileComponent: EnterOTPandDecryptFileComponent,
               private contactService: ContactServiceService,
               private route: ActivatedRoute,
               private authService: AuthService,
               public modalCtrl: ModalController,
               private globalVariablesProvider: GlobalVariablesService,
               private downloadDocumentService: DownloadDocumentService,
               private uploadDocumentsService: UploadDocumentsService,
               private popOverCtrl: PopoverController

  ) {

  }

  ionViewWillEnter () {
    this.contactService.contactsStream.subscribe(contacts => {
      this.contacts = contacts;
      this.attachmentService.getAttachments();
      this.attachmentService.attachmentStream.subscribe(data => {
        this.attachments = this.attachmentService.attachments;
        // this.attachments = data;
        this.route.paramMap.subscribe(params => {
          this.index = params.get('index');
          this.document = this.attachments[this.index];
          this.fileName = this.document.filename;
          this.fileId = this.document.file_id;
          this.fileExtension = this.fileName.substring(this.fileName.lastIndexOf('.') + 1);
          this.uploadedDate = this.document.uploaded_user_date;
          this.isEncrypted = this.document.isEncrypted;
          this.userFileEncKeyhash = this.document.userFileEncKeyHash;
          this.userFileEncIv = this.document.userFileEncIv;
          this.userFileEncTag = this.document.userFileEncTag;
          this.hybridEncTag = this.document.hybridEncTag;
          this.isUserEncrypted = this.document.isUserEncrypted;
          this.isBiometricEnabled = this.document.isBiometricEnabled;
          if(this.isUserEncrypted == true || this.isBiometricEnabled == true){
            this.lockToshow = true;
          }
          if (this.document.original_filesize !== (undefined || null)) {
            this.fileSize = this.document.original_filesize;
          }
          if (this.fileName.substring(this.fileName.lastIndexOf('.') + 1) === 'html'){
            this.nofileSize = true;
          }
         
        });
        // this.getBeneficiaries();
      });
      this.getBeneficiaries();
    });

  }

  ngOnInit () {

  }

  getBeneficiaries () {
    this.attachmentService.getBeneficiaries(this.index);
    this.tier1.length = 0;
    this.tier2.length = 0;
    this.tier3.length = 0;
    this.document = this.attachments[this.index];
    this.document.Beneficiary1.forEach(contact => {
      this.contactService.getContactDetailsbyId(contact.contactId).then(res => {
        this.beneficiary1 = res;
        this.tier1.push(this.beneficiary1);
      });
    });

    this.document.Beneficiary2.forEach(contact => {
      this.contactId = contact.contactId;
      this.contactService.getContactDetailsbyId(contact.contactId).then(res => {
        this.beneficiary2 = res;
        this.tier2.push(this.beneficiary2);
      });
    });

    this.document.Beneficiary3.forEach(contact => {
      this.contactService.getContactDetailsbyId(contact.contactId).then(res => {
        this.beneficiary3 = res;
        this.contactId = res;
        this.tier3.push(this.beneficiary3);
      });
    });

  }

  goBack () {
    this.navCtrl.back();
  }

  goto (pageName, data?) {
    this.navService.goto(pageName, data);
  }

  // public async download (documentId, filename: string) {
    
  //   this.downloadDocumentService.checkAndroidPermissions ()
  //   .then (async (status) => {
  //     this.downloadDocumentService.presentSpinner('Download in Progress...');
  //     await this.downloadDocumentService.downloadFile(documentId, filename, this.isEncrypted)
  //       .then(data => {
  //         let fileUrl: string;
  //         fileUrl = data;
  //         if(this.isEncrypted == false){
  //           this.loadingCtrl.dismiss();
  //           this.downloadDocumentService.downloadSuccessAlert(filename);
  //           this.downloadDocumentService.pushNotificationToStatusBar(fileUrl, filename);
  //         }else if(this.isEncrypted == undefined || this.isEncrypted == null || this.isEncrypted == true){
  //          // this.enterOtp(documentId,filename);
  //           this.downloadDocumentService.getKeysByFileId(documentId)
  //           .then(keyNiv => {
  //           //  var keyNiv = this.downloadDocumentService.keyNIv;
  //             this.uploadDocumentsService.decryptFile(data, keyNiv['hybridEncKey'], keyNiv['hybridEncIv'], this.hybridEncTag, '', false)
  //               .then((ext) => {

  //                 this.fileExtension = ext;
  //                 this.loadingCtrl.dismiss();
  //                 if (this.fileExtension.substring(this.fileExtension.lastIndexOf('.') + 1) !== 'encrypt') {
  //                   this.downloadDocumentService.downloadSuccessAlert(filename);
  //                   this.downloadDocumentService.pushNotificationToStatusBar(fileUrl, filename);
  //                 } else if (this.fileExtension.substring(this.fileExtension.lastIndexOf('.') + 1) === 'encrypt') {
  //                   this.presentConfirmModal(fileUrl, documentId, filename, this.userFileEncKeyhash, this.userFileEncIv, this.userFileEncTag);
  //                 }
  //               }, (error) => {
  //                 this.loadingCtrl.dismiss();
  //                 this.downloadDocumentService.downloadFailedAlert(filename);
  //               }
  //               );
  //           });
  //         }
  //     }, err => {
  //     });

  //   }, err => {
  //     this.accessDeniedAleart ();
  //   });
  // }

  public async download(documentId, filename: string){
    this.downloadDocumentService.checkAndroidPermissions ()
    .then (async (status) => {
      // this.downloadDocumentService.presentSpinner('Download in Progress...');
      await this.downloadDocumentService.downloadFile(documentId, filename, this.isEncrypted)
      .then(async (data) => {
        let fileUrl: string;
        fileUrl = data;
        if(this.isEncrypted!=undefined){
          this.checkEncryption(this.isEncrypted,fileUrl,filename,documentId)
        }else{
          
          this.downloadFile(filename,fileUrl);
        }
        
      })

      
    },
    err =>{
      this.accessDeniedAleart();
    })
  }

  async checkEncryption(isEncrypted,fileUrl,filename,documentId){
    if(isEncrypted == true){
      await this.enterOtp(documentId,filename,fileUrl).then((res)=>{
      
       })
       }else{
         this.downloadFile(filename,fileUrl);
     }
  }

  public downloadFile(filename,fileUrl) {
    this.loadingCtrl.dismiss();
          this.downloadDocumentService.downloadSuccessAlert(filename);
          this.downloadDocumentService.pushNotificationToStatusBar(fileUrl, filename);
  }

  // async enterOtp(documentId :any ,filename: String, fileUrl:any){
  //   this.authService.currentUser.subscribe((user) => {
  //     this.user = user;
  //   });
  //   this.apiService.post('user/sendOTP', {mobileNumber:this.user.profile.telephoneNumber}).subscribe(async (data) => {
  //     const popover = await this.popOverCtrl.create({
  //       component: EnterFileDownloadOtpComponent,
  //       componentProps: {fileId: documentId, filename: filename },
  //       cssClass: 'enterFileDownloadOtp-popover',
  //       });
  //     return await popover.present();
  // }), (error: any) => {
  // };
  // }
  public async downloadAfterOtpVerification (data,keyNiv,filename,documentId) {
     
    this.uploadDocumentsService.decryptFile(data, keyNiv['hybridEncKey'], keyNiv['hybridEncIv'], this.hybridEncTag, '', false)
    .then((ext) => {
      this.fileExtension = ext;
      this.loadingCtrl.dismiss();
      // if (this.fileExtension.substring(this.fileExtension.lastIndexOf('.') + 1) !== 'encrypt') {
        this.downloadDocumentService.downloadSuccessAlert(filename);
        this.downloadDocumentService.pushNotificationToStatusBar(data, filename);
    //   } else if (this.fileExtension.substring(this.fileExtension.lastIndexOf('.') + 1) === 'encrypt') {
    //     if(this.isBiometricEnabled){
          
    //     }else{
    //     this.presentConfirmModal(data, documentId, filename, this.userFileEncKeyhash, this.userFileEncIv, this.userFileEncTag, this.hybridEncTag);
    //   }
    // }
    }, (error) => {
      this.loadingCtrl.dismiss();
      this.downloadDocumentService.downloadFailedAlert(filename);
    }
    );
  }

  biometricDecrypt(fileUrl,data,filename,documentId) {
    this.presentAlert();
    window.cordova.plugins.CustomBiometricPlugin.decryptAfterBiometric(
      data['hybridEncKey'], "mdurity",
      (res) => {
        this.alert.message = '<ion-icon name="checkmark-circle"></ion-icon>';
       console.log(res);
        // this.biometricDecryptKey = res;
        data['hybridEncKey'] = res;
        document.querySelector('body');
        this.alertCtrl.dismiss();
        this.downloadAfterOtpVerification(fileUrl,data,filename,documentId)
        // return res;
      },
      (e) => console.error(e)
    );
  }

  async presentAlert() {
    this.alert = await this.alertCtrl.create({
      cssClass: 'customLoader',
      subHeader: 'Authenticate using Biometric',
      message: `<ion-icon name="finger-print" color={{'danger'}}></ion-icon>`,
      buttons: [{
        text: 'Cancel',
        role: 'cancel',
        handler: () => {
          this.cancellFingerprintAuth();
        }
      },]
    });
    await this.alert.present();
  }

  cancellFingerprintAuth() {
    window.cordova.plugins.CustomBiometricPlugin.cancellFingerprintAuth(
      (r) => { console.log(r) },
      (e) => console.log(e)
    );
  }

  public async enterOtp(documentId :any ,filename: String,fileUrl:any){
    this.loadingCtrl.dismiss();
    this.authService.currentUser.subscribe((user) => {
      this.user = user;
    });
    if(this.user.profile.telephoneNumber == ''){
      const toast = await this.toastCtrl.create({
        duration: 5000,
        message: 'For extra security, we send an OTP to your phone. Please enter a valid phone in the Profile section before trying to download the file.',
      });
      await toast.present();
      // this.authService.presentToast("For extra security, we send an OTP to your phone. Please enter a valid phone in the Profile section before trying to download the file.");
    }
    else{
   this.apiService.post('user/sendOTP', {mobileNumber:this.user.profile.telephoneNumber}).subscribe(async (data1) => {
      const popover = await this.popOverCtrl.create({
        component: EnterOTPandDecryptFileComponent,
        componentProps: {fileId: documentId, filename: filename, telephoneNumber:this.user.profile.telephoneNumber,
           fileUrl:fileUrl, isBiometricEnabled:this.isBiometricEnabled, hybridEncTag:this.hybridEncTag,
           isUserEncrypted:this.isUserEncrypted,
           userFileEncKeyhash:this.userFileEncKeyhash, userFileEncIv:this.userFileEncIv, userFileEncTag:this.userFileEncTag, },
        cssClass: 'enterFileDownloadOtp-popover',
        });
      await popover.present();
  }), (error: any) => {
  }; 
  }
  }
  

 public async decryptRndKeyWithUserKeyAndDownloadFile(data,keyNiv,filename,documentId){
  this.presentConfirmModal(data, documentId, filename, keyNiv, this.userFileEncIv, this.userFileEncTag,this.hybridEncTag);


    // this.uploadDocumentsService.decryptFile(data, keyNiv['hybridEncKey'], keyNiv['hybridEncIv'], this.hybridEncTag, '', false)
    // .then((ext) => {
    //   this.fileExtension = ext;
    //   this.loadingCtrl.dismiss();
     
    // }, (error) => {
    //   this.loadingCtrl.dismiss();
    //   this.downloadDocumentService.downloadFailedAlert(filename);
    // }
    // );
  }

accessDeniedAleart () {
    let newVar: any;
    newVar = window.navigator;
    newVar.notification.alert(
        'Download Failed',   // the message
        function () { },                      // a callback
        'Access Denied',                            // a title
        'OK'                                // the button text
    );
  }

async presentConfirmModal(savedFileurl: string, documentId, filename: string, keyNIV, userFileEncIv, userFileEncTag, hybridEncTag) {
    const modal = await this.modalCtrl.create({
      component: ConfirmPasswordComponent,
      cssClass: 'custom-confirmpass',
      componentProps: {
        fileUrl: savedFileurl, flagType: false, fileId: documentId, fileName: filename, keyNIV:keyNIV, userFileEncIv:userFileEncIv, userFileEncTag:userFileEncTag, hybridEncTag:this.hybridEncTag
      }
    });

    return await modal.present();
  }

async deleteAttachment (fileId) {
    const modal = await this.modalCtrl.create({
      component: DeletePopoverComponent,
      cssClass: 'simple-delete-modal',
      componentProps: { deleteType: 'deleteAttachment', fileId }
    });
    await modal.present();
    const { data } = await modal.onWillDismiss();
    this.navService.navigateBack();
  }

async revokeAccess (fileid, filename, contactid, tierValue) {
    const modal = await this.modalCtrl.create({
      component: DeletePopoverComponent,
      cssClass: 'simple-delete-modal',
      componentProps: { deleteType: 'revokeAccess', fileId: fileid, fileName: filename, contactId: contactid, tier: tierValue, index: this.index }
    });
    await modal.present();
    const { data } = await modal.onWillDismiss();
    this.getBeneficiaries();


  }

async addBeneficiary (fileid, filename) {
    this.globalVariablesProvider.addBeneficiaries = true;
    const modal = await this.modalCtrl.create({
      component: UploadDocumentComponent,
      componentProps: { fileId: fileid, fileName: filename }
    });
    await modal.present();
  }



}

