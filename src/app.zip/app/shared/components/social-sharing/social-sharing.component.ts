import { Component, OnInit } from '@angular/core';
import { SocialSharing } from '@ionic-native/social-sharing/ngx';
import { PopoverController, NavParams } from '@ionic/angular';
import { NavigationService } from '../../services/navigation.service';
@Component({
  selector: 'app-social-sharing',
  templateUrl: './social-sharing.component.html',
  styleUrls: ['./social-sharing.component.scss'],
})
export class SocialSharingComponent  {

  private password = 'enter password';
  durityId: any;
  userName: any;
  constructor (private socialSharing: SocialSharing, public navParams: NavParams, private popOverCtrl: PopoverController, private navService: NavigationService) {
    // this.password = navParams.get('password');
    this.userName = navParams.get('username');
    this.durityId = navParams.get('durityId');
   }

  dropdown () {
   this.popOverCtrl.dismiss();
  }


  whatsappShare () {
    this.socialSharing.shareViaWhatsApp(this.getwhatsMessage () , null, null);
    this.navService.navigateForword('/document-list');
    this.popOverCtrl.dismiss();
  }

  emailShare () {
    this.socialSharing.shareViaEmail(this.getMessage(), null, null);
    this.navService.navigateForword('/document-list');
    this.popOverCtrl.dismiss();
  }
  clipboardshare () {
  }

  private getMessage () {
    this.password = this.password;
    return `Dear one,\n \n \nThis is to inform you that I’m storing my confidential information in Durity for you. It is an AES 256 Bit encrypted file and the password to decrypt it is\n\n In case of emergency, please contact durity.life to get the documents. \n\n I also recommend that you create your own Durity account and safeguard your loved one's future. \n\n Kindly store this password safely. Durity will not be storing my password in any form. You wont be able to recover my file if password is lost and Durity won't be able to help you recover it if lost.
    \n \n Regards,\n ${this.userName}\n Durity ID is :${this.durityId}` ;
  }
  private getwhatsMessage () {
    this.password = this.password;
    return `Dear one,\n \n This is to inform you that I am storing my confidential information in Durity app for you, to access this data you need a password, please find the password below.\n\n In case of emergency, please contact durity.life to get the documents.\n\nI also recommend that you create your own Durity account and safeguard your loved ones kindly store this email safely.\n\n My encrypted password is <enter the password here>
    \n \n Regards\n ${this.userName}\n Durity ID is:${this.durityId}` ;
  }
}
