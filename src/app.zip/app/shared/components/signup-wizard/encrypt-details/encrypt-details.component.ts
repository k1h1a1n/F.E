import { Component } from '@angular/core';
import { ModalController, PopoverController } from '@ionic/angular';
import { NavigationService } from '@durity/services';
import { EncryptionPopoverComponent } from '../encryption-popover/encryption-popover.component';
import { Storage } from '@ionic/storage';
import { AuthService } from 'src/app/services/auth.service';
@Component({
  selector: 'app-encrypt-details',
  templateUrl: './encrypt-details.component.html',
  styleUrls: ['./encrypt-details.component.scss'],
})
export class EncryptDetailsComponent {
  activeSection: any = 'contacts';
  setPass: any = false;
  constructor (

    public modalController: ModalController,
    private navService: NavigationService,
    public popoverController: PopoverController,
    private storage: Storage,
    private auth: AuthService
  ) { 
    // let userEmail
    // this.auth.currentUser.subscribe(user => userEmail = user.email)
    // storage.set(userEmail, 'encrypt-details');

  }

  next () {
    this.navService.navigateForword('/security');

  }

  goBack () {
    this.navService.navigateBack ();
  }

  async aboutEncryption () {
    const popover = await this.popoverController.create({
      component: EncryptionPopoverComponent,
      translucent: true,
      backdropDismiss: false,
      cssClass: 'custom-popoverEncryption'
    });
    return await popover.present();

  }
}
