import { Component, OnInit } from '@angular/core';
import { PopoverController } from '@ionic/angular';

@Component({
  selector: 'app-encryption-popover',
  templateUrl: './encryption-popover.component.html',
  styleUrls: ['./encryption-popover.component.scss'],
})
export class EncryptionPopoverComponent  {

  constructor (public popOverCtrl: PopoverController) { }

  close () {
    this.popOverCtrl.dismiss();
  }

}
