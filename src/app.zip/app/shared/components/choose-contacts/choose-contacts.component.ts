import { Component, OnInit } from '@angular/core';
import { NavigationService } from '@durity/services';
import { ModalController, LoadingController } from '@ionic/angular';
import { Contacts } from '@ionic-native/contacts/ngx';
import { FormBuilder, FormGroup } from '@angular/forms';



@Component({
    selector: 'app-choose-contacts',
    templateUrl: './choose-contacts.component.html',
    styleUrls: ['./choose-contacts.component.scss'],
})
export class ChooseContactsComponent implements OnInit {
    public allContacts: any = [];
    chooseContactForm: FormGroup;
    checked = false;
    contactsfound = [];
    contactsArray: Array<{ contactName: string, contactNumberOne: string }> = [];
    selectedContactNumber: any = [];
    keys: string[];
    selectedContactsArray: Array<{ selectedContactName: string, selectedContactNumberOne: string, primaryEmail: string }> = [];
    unselectedContactsArray: Array<{ unselectedContactName: string, unselectedContactNumberOne: string, unselectedEmail: string }> = [];
    selectedContactName: string;
    unselectedContactName: string;
    unselectedContactNumber: any = [];
    myContacts: any[];
    primaryEmail: any;
    unselectedEmail: string;
    myContactsBackup: any[];
    cts: any;
     newSelectedContacts = [];
    constructor (public navService: NavigationService,
                 public modalCtrl: ModalController,
                 private contacts: Contacts,
                 private fb: FormBuilder,
                 public loadingCtrl: LoadingController
    ) {
        this.search('');
        this.loadContacts();
        this.chooseContactForm = this.fb.group({
            cont: [null]
        });
    }

    ngOnInit () { }

    goto (pageName, data?) {
        this.navService.goto(pageName, data);
    }

    goBack () {
        this.modalCtrl.dismiss({
            dismissed: true
        });
    }
    async loadContacts () {

        const options = {
            filter: '',
            multiple: true,
            hasPhoneNumber: true
        };
        const loader = await this.loadingCtrl.create({
            message: 'Loading...'
        });
        (await loader).present();
        this.contacts.find(['*'], options).then((contacts: any) => {
            loader.dismiss();
            this.myContacts = contacts.map((elem) => ({
                addresses: elem._objectInstance.addresses,
                birthday: elem._objectInstance.birthday,
                categories: elem._objectInstance.categories,
                displayName: elem._objectInstance.displayName,
                emails: elem._objectInstance.emails,
                id: elem._objectInstance.id,
                ims: elem._objectInstance.ims,
                name: elem._objectInstance.name,
                nickname: elem._objectInstance.nickname,
                note: elem._objectInstance.note,
                organizations: elem._objectInstance.organizations,
                phoneNumbers: elem._objectInstance.phoneNumbers,
                photos: elem._objectInstance.photos,
                rawId: elem._objectInstance.rawId,
                urls: elem._objectInstance.urls,
                checked: 'false'
            }));
            this.myContacts.sort(this.GetSortOrder('displayName'));
            this.myContactsBackup = this.myContacts;
        }, (error) => {
            loader.dismiss();
            this.modalCtrl.dismiss ();
        });

    }

    alertDismissed () {
        let newVar: any;
        newVar = window.navigator;
        newVar.notification.alert(
            'Document couldnt be uploaded.',   // the message
            function () { },                      // a callback
            'Access Denied',                            // a title
            'OK'                                // the button text
        );
    }

    GetSortOrder (prop) {
        return function (a, b) {
            if (a[prop] > b[prop]) {
                return 1;
            } else if (a[prop] < b[prop]) {
                return -1;
            }
            return 0;
        };
    }


    async search (q) {
        this.myContacts = this.myContactsBackup;
        this.myContacts = this.myContacts.filter(contact => {
            if (!!contact.displayName && typeof contact.displayName === 'string') {
                return contact.displayName.toLowerCase().indexOf(q.toLowerCase()) > -1;
            }
        });

    }

    onKeyUp (ev) {
        this.search(ev.target.value);
    }

    getContact (contactName: string, contactNumber, email: string, isChecked: boolean) {

        if (isChecked === true) {
            this.selectedContactName = contactName;
            this.selectedContactNumber = contactNumber;
            this.primaryEmail = email;
            const selected = this.selectedMobileContacts(this.selectedContactName, this.selectedContactNumber, this.primaryEmail);
        } else {
            if (isChecked === false) {
                this.unselectedContactName = contactName;
                this.unselectedContactNumber = contactNumber;
                this.unselectedEmail = email;
                const unselected = this.unselectedMobileContacts(this.unselectedContactName, this.unselectedContactNumber, this.unselectedEmail);
            }
        }
    }

    gotoContacts () {
        this.contactsList();
        this.modalCtrl.dismiss({
            selectedContacts: this.selectedContactsArray
        });
    }

    selectedMobileContacts (name: string, mobile: string, email: string) {

        this.selectedContactsArray.push({ selectedContactName: name, selectedContactNumberOne: mobile, primaryEmail: email });
        // tslint:disable-next-line:prefer-for-of
    }

    unselectedMobileContacts (name: string, mobile: string, email: string) {
        this.unselectedContactsArray.push({ unselectedContactName: name, unselectedContactNumberOne: mobile, unselectedEmail: email });
    }

    contactsList () {
        // tslint:disable-next-line: prefer-for-of
        for (let j = 0; j < this.unselectedContactsArray.length; j++) {
            // tslint:disable-next-line: prefer-for-of
            for (let i = 0; i < this.selectedContactsArray.length; i++) {
                if (this.selectedContactsArray[i].selectedContactName === this.unselectedContactsArray[j].unselectedContactName &&
                    this.selectedContactsArray[i].selectedContactNumberOne === this.unselectedContactsArray[j].unselectedContactNumberOne
                ) {
                    this.selectedContactsArray.splice(i, 1);
                }
            }
        }
    }

    addedContacts (name: any, mobile: any) {
        this.contactsArray.push({ contactName: name, contactNumberOne: mobile });
    }
}






