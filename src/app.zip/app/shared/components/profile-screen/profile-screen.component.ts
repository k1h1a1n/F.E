import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PopoverController, ModalController } from '@ionic/angular';
import { UpdateProfileComponent } from '../update-profile/update-profile.component';
import { AuthService } from 'src/app/services/auth.service';
import { NavigationService } from '../../services/navigation.service';
import { SignupWizardService } from '../../services/signup-wizard.service';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-profile-screen',
  templateUrl: './profile-screen.component.html',
  styleUrls: ['./profile-screen.component.scss'],
})
export class ProfileScreenComponent implements OnInit {

  user;
  userName: string;
  isAuthenticated: boolean;
  durityid = 12345;
  profileForm: FormGroup;
  constructor (
    private fb: FormBuilder,
    private dom: DomSanitizer,
    public popoverController: PopoverController,
    public modalController: ModalController,
    private signUpWizardService: SignupWizardService,
    private authService: AuthService,
    private navService: NavigationService
  ) {
    this.profileForm = this.fb.group({
      Name: ['', Validators.required],
      Email1: ['', Validators.required],
      Email2: [''],
      Phone1: ['', Validators.required],
      Phone2: ['']
    });

    this.getUser();

}

ngOnInit () {}

getUser () {
  this.authService.currentUser.subscribe((user) => {
    this.user = user;
  });
}

async editProfile () {
  const modalController = await this.modalController.create({
    component: UpdateProfileComponent,
    backdropDismiss: false,
    showBackdrop: true,
    cssClass: 'custom-updatePopover'
  });
  await modalController.present();

}

public get profilePic () {
  return this.dom.bypassSecurityTrustUrl(`data:${this.user.profile.picture.contentType};base64,${this.user.profile.picture.data}`);

}

uploadProfilePic () {
  this.signUpWizardService.addPhoto ('profilePic');

}

goto (pageName, data?) {
  this.navService.goto(pageName, data);
}

cancel () {
  this.navService.navigateRoot('/home');
}

}
