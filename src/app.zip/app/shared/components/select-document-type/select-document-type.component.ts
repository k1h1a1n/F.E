import { Component, OnInit} from '@angular/core';
import { NavigationService } from '@durity/services';
import {  PopoverController, NavController,  } from '@ionic/angular';
import { TextNoteComponent } from '../text-note/text-note.component';
import { SignupWizardService } from '../../services/signup-wizard.service';
import { GlobalVariablesService } from 'src/app/services/global-variables.service';
import { AndroidPermissions } from '@ionic-native/android-permissions/ngx';

@Component({
  selector: 'app-select-document-type',
  templateUrl: './select-document-type.component.html',
  styleUrls: ['./select-document-type.component.scss'],
})
export class SelectDocumentTypeComponent implements OnInit {
  constructor (
    private wizardService: SignupWizardService,
    private androidPermissions: AndroidPermissions,
    private navService: NavigationService,
    public popOverCtrl: PopoverController,
    private navCtrl: NavController,
    public globalvariablesProvider: GlobalVariablesService

  ) { }

  ngOnInit () {
    this.globalvariablesProvider.addBeneficiaries = false;
  }

  goto (pageName: any, data?: any) {
    this.navService.goto(pageName, data);
  }

  goBack () {
  this.navService.navigateBack ();
  }

  async selectDocType (type) {
    if (type === 'file') {

      this.wizardService.getFile('log-in');

    } else if (type === 'note') {
      this.globalvariablesProvider.uploadType = 'text-note';
      this.androidPermissions.hasPermission(this.androidPermissions.PERMISSION.READ_EXTERNAL_STORAGE)
        .then(status => {
          if (status.hasPermission) {
            this.navService.navigateForword(['/text-note']);
          } else {
            this.androidPermissions.requestPermission(this.androidPermissions.PERMISSION.READ_EXTERNAL_STORAGE)
            .then(response => {
              if (response.hasPermission) {
                this.navService.navigateForword(['/text-note']);
            }
          });
        }
      });
    } else if (type === 'photo') {

      this.wizardService.addPhoto('log-in');

    } else if (type === 'audio') {
      this.wizardService.captureAudio('log-in');

    } else if (type === 'video') {

      this.wizardService.addVideo('log-in');
    }
  }

  async presentModal () {
    const modal = await this.popOverCtrl.create({
      component: TextNoteComponent,
      componentProps: {},
      cssClass: 'custom-PopOver'
    });
    await modal.present();
    modal.onDidDismiss().then(data => {
    });

  }
}
