import { NgModule } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import {UploadDocumentComponent, ChooseContactsComponent, ConfirmPasswordComponent, CreateContactComponent, UserEncryptionOptionsComponent,
     SelectDocumentTypeComponent, SetPasswordComponent, ShareDetailsComponent, DisclaimerComponent, ViewDocumentComponent } from './components';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SecurityComponent } from './components/signup-wizard/security/security.component';
import { EncryptDetailsComponent } from './components/signup-wizard/encrypt-details/encrypt-details.component';
import { EverythingSetComponent } from './components/signup-wizard/everything-set/everything-set.component';
import { StorePasswordComponent } from './components/store-password/store-password.component';
import { TextNoteComponent } from './components/text-note/text-note.component';
import { EncryptionPopoverComponent } from './components/signup-wizard/encryption-popover/encryption-popover.component';
import { SocialSharingComponent } from './components/social-sharing/social-sharing.component';
import { RecommendationsComponent } from './recommendations/recommendations.component';
import { AddContactsComponent } from './components/signup-wizard/add-contacts/add-contacts.component';
import { DeletePopoverComponent } from './components/delete-popover/delete-popover.component';
import { EditContactComponent } from './components/edit-contact/edit-contact.component';
import { AddContactEmailComponent } from './components/add-contact-email/add-contact-email.component';
import { ToastComponent } from './components/toast/toast.component';
import { TextNoteUploadComponent } from './components/text-note-upload/text-note-upload.component';
import { FeedbackComponent } from './components/feedback/feedback.component';
import { FeedbackSubmitComponent } from './components/feedback-submit/feedback-submit.component';
import { FaqsComponent } from './components/faqs/faqs.component';
import { EnterFileDownloadOtpComponent } from './components/enter-file-download-otp/enter-file-download-otp.component';
import { EnterOTPandDecryptFileComponent } from './components/enter-otpand-decrypt-file/enter-otpand-decrypt-file.component';
import { ProfileScreenComponent } from './components/profile-screen/profile-screen.component';
import { ProfileSubmitComponent } from './components/profile-submit/profile-submit.component';
import { UpdateProfileComponent } from './components/update-profile/update-profile.component';
import { UploadProfilePicComponent } from './components/upload-profile-pic/upload-profile-pic.component';
import { ChangePasswordComponent } from './components/change-password/change-password.component';
import { ContactUsComponent } from './components/contact-us/contact-us.component';
import { SettingsComponent } from './components/settings/settings.component';



@NgModule({
    declarations: [ AddContactsComponent, EverythingSetComponent, EncryptDetailsComponent, SecurityComponent, ShareDetailsComponent,
        UploadDocumentComponent, DeletePopoverComponent, EditContactComponent, AddContactEmailComponent,UserEncryptionOptionsComponent,
        ChooseContactsComponent, ConfirmPasswordComponent, CreateContactComponent, RecommendationsComponent,
        SelectDocumentTypeComponent, SetPasswordComponent, ShareDetailsComponent, TextNoteUploadComponent,EnterOTPandDecryptFileComponent,
        DisclaimerComponent, ViewDocumentComponent, ToastComponent, UploadProfilePicComponent,EnterFileDownloadOtpComponent,
        StorePasswordComponent, EncryptionPopoverComponent, TextNoteComponent, SocialSharingComponent, FeedbackComponent, FeedbackSubmitComponent,
         FaqsComponent, ProfileScreenComponent, ProfileSubmitComponent, UpdateProfileComponent, ChangePasswordComponent, ContactUsComponent, SettingsComponent
    ],
    imports: [
        IonicModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule
    ],
    exports: [
        IonicModule, AddContactsComponent, SecurityComponent, EverythingSetComponent, EncryptDetailsComponent, ShareDetailsComponent,
        CommonModule, UploadDocumentComponent, DeletePopoverComponent, EditContactComponent, AddContactEmailComponent, ToastComponent,
        ChooseContactsComponent, ConfirmPasswordComponent, EncryptionPopoverComponent, RecommendationsComponent, TextNoteUploadComponent,
        CreateContactComponent, SelectDocumentTypeComponent, SetPasswordComponent, ShareDetailsComponent,UserEncryptionOptionsComponent,
        DisclaimerComponent, ViewDocumentComponent, UploadProfilePicComponent,EnterFileDownloadOtpComponent,EnterOTPandDecryptFileComponent,
        StorePasswordComponent, TextNoteComponent, EncryptionPopoverComponent, SocialSharingComponent, FeedbackComponent, FeedbackSubmitComponent, 
        FaqsComponent, ProfileScreenComponent, ProfileSubmitComponent, UpdateProfileComponent, ChangePasswordComponent, ContactUsComponent, SettingsComponent
    ],
    providers: [],
    entryComponents: [ AddContactsComponent, SecurityComponent, EverythingSetComponent, EncryptDetailsComponent, ShareDetailsComponent,
        UploadDocumentComponent, RecommendationsComponent, DeletePopoverComponent, EditContactComponent, AddContactEmailComponent, ToastComponent,
        ChooseContactsComponent,  ConfirmPasswordComponent, CreateContactComponent, EncryptionPopoverComponent, TextNoteUploadComponent,
         SelectDocumentTypeComponent, SetPasswordComponent, ShareDetailsComponent,EnterFileDownloadOtpComponent,EnterOTPandDecryptFileComponent,
        DisclaimerComponent, ViewDocumentComponent, UploadProfilePicComponent,UserEncryptionOptionsComponent,
        StorePasswordComponent, TextNoteComponent, EncryptionPopoverComponent, SocialSharingComponent, FeedbackSubmitComponent, FeedbackComponent,
        FaqsComponent, ProfileScreenComponent, ProfileSubmitComponent, UpdateProfileComponent, ChangePasswordComponent, ContactUsComponent, SettingsComponent
    ]
})
export class SharedModule { }
