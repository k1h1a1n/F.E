import { Component, OnDestroy, AfterViewInit, OnInit } from '@angular/core';
import { Platform, MenuController, ModalController } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { Router } from '@angular/router';
import { AuthService } from './services/auth.service';
import { SecureStorage, SecureStorageObject } from '@ionic-native/secure-storage/ngx';
import { SignupWizardService } from './shared/services/signup-wizard.service';
import { NavigationService } from '@durity/services';
import { GlobalVariablesService } from './services/global-variables.service';
import { BnNgIdleService } from 'bn-ng-idle';
import { Dialogs } from '@ionic-native/dialogs/ngx';
import { GooglePlus } from '@ionic-native/google-plus/ngx';
import { DeletePopoverComponent } from './shared/components/delete-popover/delete-popover.component';




@Component({
    selector: 'app-root',
    templateUrl: 'app.component.html'
})
export class AppComponent {
    user: any;
    public appPages = [
        {
            title: 'Refer a Friend',
            type: 'navigate',
            // url: '/list',
            icon: 'share'
        },
        {
            title: 'FAQ\'s',
            type: 'navigate',
            url: '/faqs',
            icon: 'help-circle-outline'
        },
        {
            title: 'Feed Back',
            type: 'navigate',
            url: '/feedback',
            icon: 'text'
        },
        {
            title: 'Extra Security',
            type: 'navigate',
            url: '/security',
            icon: 'folder'
        }, {
            title: 'Settings',
            type: 'navigate',
            url: '/settings',
            icon: 'settings'
        },
        // {
        //     title: 'Delete Account',
        //     type: 'popover',
        //     // url: '/faqs',
        //     // src: 'how_to_reg-24px.svg'
        // },
    ];

    otherMenus: any = [
        {
            title: 'Sign Out ',
            url: '/log-out',
            icon: 'log-out'
        }

    ];

    userName: string;
    isAuthenticated: boolean;
    backButtonSubscription: any;
    private secureStorageObject: SecureStorageObject;
    private deviceSecure = false;

    constructor (
        private platform: Platform,
        private splashScreen: SplashScreen,
        private statusBar: StatusBar,
        private menu: MenuController,
        private modalCtrl: ModalController,
        private router: Router,
        private auth: AuthService,
        private navigationService: NavigationService,
        private googlePlus: GooglePlus,
        private secureStorage: SecureStorage,
        private service: SignupWizardService,
        private bnIdle: BnNgIdleService,
        public globalVariablesProvider: GlobalVariablesService,
        private dialogs: Dialogs,
        private navService: NavigationService
    ) {
        this.getUser();
        this.initializeApp();
        this.bnIdle.startWatching(1000).subscribe((res) => {
            if (res && this.router.url !== '/login') {
                alert('Session Timeout');
                this.navigationService.navigateRoot(['/login']);
            }
          });
    }


    initializeApp () {
        this.platform.ready().then(() => {
            this.statusBar.styleDefault();
            this.statusBar.overlaysWebView(false);
            this.splashScreen.hide();
            this.navigationService.registerHomeBackButtonExit();
        });

    }


    getUser () {
        this.auth.currentUser.subscribe((user) => {
          this.user = user;
          });
    }


    goBack () {
        this.menu.close();
    }

    goto (page) {
        if (page.type === 'popover') {
            this.deleteUserAccount(this.user);
        } else {
            this.router.navigate(['/' + page.url]);
            this.menu.close();
        }
    }

    gotoProfile () {
        this.navService.navigateForword('/profile-screen');
        this.menu.close();
    }

    gotoLogin (page) {
        this.router.navigate(['/' + page.url]);
        this.googlePlus.logout();
        this.auth.purgeAuth();
        this.menu.close();
    }

    async deleteUserAccount(User) {
        this.menu.close();
        const modal = await this.modalCtrl.create({
            component: DeletePopoverComponent,
            cssClass: 'simple-delete-user-modal',
            componentProps: { deleteType: 'deleteUserAccount', user: User, contactId: '', fileName: '' }
        });
        await modal.present();
    }
}
