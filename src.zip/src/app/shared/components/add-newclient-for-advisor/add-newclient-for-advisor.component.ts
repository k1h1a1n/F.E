import { Component, OnInit } from '@angular/core';
import { NavigationService } from '@durity/services';
import { Validators, FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { LoadingController } from '@ionic/angular';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-add-newclient-for-advisor',
  templateUrl: './add-newclient-for-advisor.component.html',
  styleUrls: ['./add-newclient-for-advisor.component.scss'],
})
export class AddNewclientForAdvisorComponent implements OnInit {
  userForm: FormGroup;
  advisorDetails: any;

  constructor(
    private navService: NavigationService,
    public formBuilder: FormBuilder,
    public loaderCtrl: LoadingController,
    private authService: AuthService,
  ) { 
    this.authService.currentUser.subscribe((user) => {
      this.advisorDetails = user;
    });
    this.userForm = this.formBuilder.group({
      name: new FormControl('', Validators.compose( [Validators.required])),
      email: new FormControl('', Validators.compose([
        Validators.required,
        Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
      ])),
      phoneNumber: new FormControl('', Validators.compose( [ Validators.required, Validators.maxLength(15),Validators.minLength(10),
        Validators.pattern(String.raw`^[0-9]*$`)]))
  });
  }

  ngOnInit() {}

  goBack(){
    this.navService.navigateBack ();
  }

  async onSubmit(){
    console.log(this.userForm.value);
    if ( this.userForm.valid) {
      // Object.keys(this.userForm.controls).forEach((key) =>
      // this.userForm.get(key).setValue(this.userForm.get(key).value.trim()));
      const loader = await this.loaderCtrl.create({
          message: 'Please wait...'
      });
      (await loader).present();

      const credentials = {
          name : this.userForm.value.name,
          email: this.userForm.value.email,
          telephoneNumber: this.userForm.value.phoneNumber ,
          password: "12345678",
          isUserAnAdvisor: false,
          advisorCode:this.advisorDetails.profile.advisorCode,
          advisorName:this.advisorDetails.profile.advisorName,
          advisorUrl:this.advisorDetails.profile.advisorUrl,
          createdByAdvisor: true

                };
      this.authService.attemptAuth('addClient', credentials).then(res => {
             this.loaderCtrl.dismiss();
            //  this.navService.goto('home');
            this.navService.navigateForword('/home');
         
         }).catch(err => {
             this.loaderCtrl.dismiss();
             this.authService.presentToast('Error in Registering, Please try after sometime');
         });
  }
  }


}
