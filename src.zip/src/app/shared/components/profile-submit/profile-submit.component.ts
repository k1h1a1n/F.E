import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-submit',
  templateUrl: './profile-submit.component.html',
  styleUrls: ['./profile-submit.component.scss'],
})
export class ProfileSubmitComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
